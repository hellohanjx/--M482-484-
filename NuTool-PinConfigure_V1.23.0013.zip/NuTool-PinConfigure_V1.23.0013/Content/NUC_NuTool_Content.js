// Note that remember to delete the Content/Nu_config.cfg file after modifying this file.
// tool content
NUTOOL_PIN.g_toolName = 'NuTool - PinConfigure_V1.23.0013';
NUTOOL_PIN.g_horizontalIndexArray = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'R', 'T', 'U', 'V', 'W', 'Y'];
NUTOOL_PIN.g_toolbarRemovedIndices = '';
NUTOOL_PIN.g_cfg_chipSeries = [];
NUTOOL_PIN.g_chipType_default = '';
NUTOOL_PIN.g_partNumber_package_default = '';
NUTOOL_PIN.g_chipSilkScreenPrint_default = '';
NUTOOL_PIN.g_briefName_default = '';
NUTOOL_PIN.g_copyrightCompanyName_default = '';
NUTOOL_PIN.g_anotherNameForNuCAD = '';
