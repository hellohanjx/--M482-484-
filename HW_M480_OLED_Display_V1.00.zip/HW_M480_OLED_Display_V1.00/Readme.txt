/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* Copyright (c) 2019 by Nuvoton Technology Corporation                                                    */
/* All rights reserved                                                                                     */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/
/*                                                                                                         */
/* NuMicro(R) M480 OLED Display Hardware Package V1.00                                	   	           */
/*                                                                                                         */
/*---------------------------------------------------------------------------------------------------------*/

Introduction:
This reference design is based on NuMicro M480 series which control a 2�� OLED display and play GIF on it. 
M480 series run up to 192 MHz with 512 kB embedded Flash memory and 160 kB embedded SRAM. The high performance 
MCU decodes GIF motion graphics smoothly. In addition, the library has built-in font libraries. User also can 
load various font libraries through the Nuvoton font conversion tool.

This file includes the Hardware Schematic and PCB/Layout Gerber of OLED Display.


File Path:

	\\HW_M480_OLED_Display_V1.00\